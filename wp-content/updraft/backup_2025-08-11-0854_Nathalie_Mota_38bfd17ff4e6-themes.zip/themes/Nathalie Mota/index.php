<?php get_header(); ?>

<?php get_template_part('archive-photos'); ?>

<?php get_footer(); ?>