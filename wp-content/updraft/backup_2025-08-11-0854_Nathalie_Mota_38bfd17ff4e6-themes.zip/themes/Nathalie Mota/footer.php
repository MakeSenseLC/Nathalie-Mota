<?php wp_nav_menu( array( 'menu' => 'Footer' ) );
    get_template_part( 'templates/modale-contact' ); 
    get_template_part( 'templates/light-box' );
    wp_footer(); ?>
</body>
</html>